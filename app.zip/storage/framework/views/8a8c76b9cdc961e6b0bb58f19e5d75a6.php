

<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Shopping Cart</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(count($cart) > 0): ?>
            <div class="row">
                <div class="col-md-8">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="<?php echo e($item['image'] ?? 'https://via.placeholder.com/100'); ?>" class="img-fluid"
                                            alt="<?php echo e($item['title']); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <h5><?php echo e($item['title']); ?></h5>
                                        <p class="text-muted">Instructor: <?php echo e($item['instructor']); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <h5>$<?php echo e($item['price']); ?></h5>
                                        <a href="<?php echo e(route('cart.remove', $item['id'])); ?>"
                                            class="btn btn-danger btn-sm">Remove</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-3">
                        <a href="<?php echo e(route('cart.clear')); ?>" class="btn btn-warning">Clear Cart</a>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Continue Shopping</a>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h4>Order Summary</h4>
                            <hr>
                            <p>Total: <strong>$<?php echo e($total); ?></strong></p>
                            <!-- In cart.blade.php, replace the checkout button -->
                            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success btn-lg w-100">Proceed to Checkout</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Your cart is empty. <a href="<?php echo e(route('products.index')); ?>">Browse courses</a>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\coursehub\resources\views/cart/index.blade.php ENDPATH**/ ?>