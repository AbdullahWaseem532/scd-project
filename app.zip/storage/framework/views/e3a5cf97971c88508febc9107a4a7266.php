

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Courses</h1>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-1"></i>Add New Course
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">All Courses</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/50'); ?>" 
                                     alt="<?php echo e($product->title); ?>" 
                                     class="rounded me-3" width="50" height="50">
                                <div>
                                    <h6 class="mb-0"><?php echo e(Str::limit($product->title, 40)); ?></h6>
                                    <small class="text-muted"><?php echo e($product->slug); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-secondary"><?php echo e($product->category->name); ?></span>
                        </td>
                        <td>
                            <div>
                                <strong class="text-primary">$<?php echo e($product->final_price); ?></strong>
                                <?php if($product->discount_price): ?>
                                <br>
                                <small class="text-muted text-decoration-line-through">$<?php echo e($product->price); ?></small>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo e($product->stock > 0 ? 'success' : 'danger'); ?>">
                                <?php echo e($product->stock); ?> in stock
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo e($product->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($product->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td><?php echo e($product->created_at->format('M d, Y')); ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>" 
                                   class="btn btn-sm btn-outline-info" target="_blank">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.products.edit', $product)); ?>" 
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" 
                                      method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" 
                                            onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            <?php echo e($products->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\coursehub\resources\views/admin/products/index.blade.php ENDPATH**/ ?>